const express = require('express')
const app = express() 
const port = 3000
app.use(express.json())
const DBCONNECTION = require('./database/connection') //constante de banco de dados

DBCONNECTION()

const router = require('./routes/routes')
app.use(router)







app.listen(port, () => {
    console.log("aplicação rodando na porta ", port)

})