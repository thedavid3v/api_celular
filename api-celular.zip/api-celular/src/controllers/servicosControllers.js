const Servico = require('../models/Servicos')

//nossas funções

async function create(req,res){
    const reqCorpo = new Servico(req.body)
    const cadastrarServico = await reqCorpo.save()
    res.status(200).json(cadastrarServico)
    



    
}
//Getall Buscar todos GET
//GetByID Buscar por ID GET
//UPDATE PUT 
//Remove Delete

module.exports = {
    create





}
// exportando minhas funções para rotas
