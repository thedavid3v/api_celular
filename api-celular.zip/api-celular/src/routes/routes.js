const express = require('express')
const router = express.Router()
const servicosControllers = require('../controllers/servicosControllers')

router.post ('/servico', servicosControllers.create)

module.exports = router
//exportando minha rotas para o index
