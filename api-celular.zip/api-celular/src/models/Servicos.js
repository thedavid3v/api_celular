const mongoose = require('mongoose') // importando banco de dados
//MEU MODELO ESQUEMA
const ServicoSchema = new mongoose.Schema({
    gerente: {
        type : String,
        required: true
    },
    tecnico: {
        type : String,
        required: true
    },
    fornecedor: {
        type : String,
        required: true
    },
    estagiario: {
        type : String,
        required: true
    },
    recursos_humanos: {
        type : String,
        required: true
    },


},{
    timestamps:true //tempo registrado
}


)
const Servico = mongoose.model('servico',ServicoSchema)

module.exports = Servico
//Exportando serviço para usar nos meus controles
